SET GLOBAL local_infile=1;
LOAD DATA LOCAL INFILE "d:\\xampp\\htdocs\\sid\\clean_sid.csv"
INTO TABLE desa
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ';'
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(@no, @nama_kecamatan, @nama_desa, @alamat_website)
SET
  no = NULLIF(@no, ''),
  nama_kecamatan = NULLIF(@nama_kecamatan, ''),
  nama_desa = NULLIF(@nama_desa, ''),
  alamat_website = NULLIF(@alamat_website, '');
