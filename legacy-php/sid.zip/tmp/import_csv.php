<?php
ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/../config.php';
$db = db();

// Pastikan kolom db_penduduk tersedia
$hasCol = false;
if ($res = $db->query("SHOW COLUMNS FROM desa LIKE 'db_penduduk'")) {
  $hasCol = ($res->num_rows > 0);
}
if (!$hasCol) {
  $db->query("ALTER TABLE desa ADD COLUMN db_penduduk VARCHAR(32) NULL");
}

$csv = __DIR__ . DIRECTORY_SEPARATOR . 'sid1.csv';
if (!file_exists($csv)) {
  echo "<p>File sid1.csv tidak ditemukan. Pastikan file berada di root proyek.</p>";
  exit;
}

$inserted = 0; $updated = 0; $skipped = 0; $errors = 0;

if (($fh = fopen($csv, 'r')) !== false) {
  $meta = fgetcsv($fh); // ignore meta line
  $header = fgetcsv($fh);
  $cols = [];
  for ($i=0; $i<count($header); $i++) { $cols[$header[$i]] = $i; }
  $idxKec = $cols['Nama Kecamatan'] ?? null;
  $idxDesa = $cols['Nama Desa'] ?? null;
  $idxDb  = $cols['Database Penduduk'] ?? null;
  $currentKec = '';

  while (($row = fgetcsv($fh)) !== false) {
    if ($idxDesa === null || $idxDb === null) { $errors++; break; }
    $kec = ($idxKec !== null && isset($row[$idxKec]) && trim($row[$idxKec]) !== '') ? trim($row[$idxKec]) : $currentKec;
    if ($idxKec !== null && isset($row[$idxKec]) && trim($row[$idxKec]) !== '') { $currentKec = $kec; }
    $desa = isset($row[$idxDesa]) ? trim($row[$idxDesa]) : '';
    $dbp  = isset($row[$idxDb]) ? trim($row[$idxDb]) : '';
    if ($kec === '' || $desa === '') { $skipped++; continue; }

    // Cek apakah sudah ada baris desa
    $stmt = $db->prepare("SELECT id FROM desa WHERE nama_kecamatan=? AND nama_desa=? LIMIT 1");
    $stmt->bind_param('ss', $kec, $desa);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
      // update db_penduduk
      $stmt->bind_result($id);
      $stmt->fetch();
      $stmt2 = $db->prepare("UPDATE desa SET db_penduduk=? WHERE id=?");
      $stmt2->bind_param('si', $dbp, $id);
      $stmt2->execute();
      $updated++;
    } else {
      // insert minimal info
      $stmt3 = $db->prepare("INSERT INTO desa (nama_kecamatan, nama_desa, db_penduduk) VALUES (?, ?, ?)");
      $stmt3->bind_param('sss', $kec, $desa, $dbp);
      if ($stmt3->execute()) { $inserted++; } else { $errors++; }
    }
    $stmt->free_result();
  }
  fclose($fh);
}

?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Import CSV ke MySQL</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-900">
  <div class="max-w-3xl mx-auto px-4 py-8">
    <div class="bg-white rounded-xl shadow p-6">
      <h1 class="text-xl font-semibold mb-3">Migrasi CSV ke MySQL</h1>
      <p class="text-sm text-gray-700">Proses memindahkan data status <span class="font-medium">Database Penduduk</span> dari <code>sid1.csv</code> ke kolom <code>desa.db_penduduk</code>.</p>
      <div class="mt-4 grid grid-cols-2 gap-4 text-sm">
        <div class="p-3 rounded-lg bg-emerald-50 text-emerald-700">Diperbarui: <span class="font-semibold"><?= $updated ?></span></div>
        <div class="p-3 rounded-lg bg-blue-50 text-blue-700">Ditambahkan: <span class="font-semibold"><?= $inserted ?></span></div>
        <div class="p-3 rounded-lg bg-gray-100 text-gray-700">Diabaikan: <span class="font-semibold"><?= $skipped ?></span></div>
        <div class="p-3 rounded-lg bg-rose-50 text-rose-700">Error: <span class="font-semibold"><?= $errors ?></span></div>
      </div>
      <div class="mt-6 text-xs text-gray-500">Setelah migrasi, halaman akan membaca data hanya dari MySQL.</div>
      <div class="mt-4 flex items-center gap-2">
        <a href="index.php" class="px-3 py-2 rounded-lg bg-blue-600 text-white text-sm">Ke Dashboard</a>
        <a href="desa.php" class="px-3 py-2 rounded-lg bg-gray-800 text-white text-sm">Ke Daftar Desa</a>
      </div>
    </div>
  </div>
  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
